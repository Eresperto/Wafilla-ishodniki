package com.example.ebuchaiabd

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ebuchaiabd.ui.theme.EbuchaiaBDTheme

class NewCreatePrj : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
prjcreate()
            Shapka()
        }

    }
    @Composable
    fun Shapka(){
        Row(Modifier/*.fillMaxWidth()*/) {
            Image(
                modifier = Modifier.fillMaxWidth(),
                painter = painterResource(id = R.drawable.group45), contentDescription = "topBAr", contentScale = ContentScale.FillWidth)
        }
    }

    @Composable
    @Preview(showBackground = true)
    fun prjcreate(){
        var text1 by remember { mutableStateOf("") }
        var text2 by remember { mutableStateOf("") }
        var text3 by remember { mutableStateOf("") }
        var text4 by remember { mutableStateOf("") }

        var toRas= Intent(this, Raschet::class.java)

            //var toNEWNEWRegg= Intent(this, NewNewREg::class.java)

        var toNewReg = Intent(this, NewReg::class.java)

        var toAuth = Intent(this,AuthActivity::class.java)

        val intent_reg = Intent(this, Onboardings::class.java)

        val toSettings = Intent(this,Settings::class.java)


        val toProfile = Intent(this,NewLk::class.java)




            Column(modifier = Modifier
                .padding(top = 46.dp)
                .background(Color(red = 27, green = 45, blue = 59), shape = RoundedCornerShape(20.dp))
                .fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally/*, shape = RoundedCornerShape(20.dp)*/)
            {

                Text(modifier =Modifier.padding(top=50.dp),text = " Заполните поля и создайте свой проект", color = Color.White, fontSize = 20.sp)

                Text(modifier =Modifier.padding(top=20.dp),text = "Название проекта", color = Color.White, fontSize = 17.sp)

                Box(modifier  =Modifier.padding(top=15.dp)/*.offset(y=100.dp)*/,contentAlignment = Alignment.Center){

                    Image( modifier = Modifier/*.background()*/
                        .height(50.dp)
                        .width(369.dp),painter = painterResource(id = R.drawable.edt), contentDescription = "")

                    TextField(
                        modifier = Modifier/*.background()*/
                            /* .height(50.dp)
                             .width(269.dp)*/
                            .alpha(0.001f),
                        value = text1,

                        onValueChange = { text1 = it },
                        label = { Text(modifier = Modifier.alpha(1f),text="Label") }
                    )

                    Text(text = "$text1", color = Color.White, fontSize = 15.sp)

                }
                Text(modifier =Modifier.padding(top=30.dp),text = "Опишите идею проекта", color = Color.White, fontSize = 15.sp)
                Box(modifier  =Modifier.padding(top=15.dp)/*.offset(y=100.dp)*/,contentAlignment = Alignment.Center){

                    Image( modifier = Modifier/*.background()*/
                        .height(50.dp)
                        .width(369.dp),painter = painterResource(id = R.drawable.edt), contentDescription = "")

                    TextField(
                        modifier = Modifier/*.background()*/
                            /* .height(50.dp)
                             .width(269.dp)*/
                            .alpha(0.001f),
                        value = text2,

                        onValueChange = { text2 = it },
                        label = { Text(modifier = Modifier.alpha(1f),text="Label") }
                    )

                    Text(text = "$text2", color = Color.White, fontSize = 15.sp)
                }
                Text(modifier =Modifier.padding(top=30.dp),text = "Целевая аудитория проекта", color = Color.White, fontSize = 15.sp)
                Box(modifier  =Modifier.padding(top=15.dp)/*.offset(y=100.dp)*/,contentAlignment = Alignment.Center){

                    Image( modifier = Modifier/*.background()*/
                        .height(50.dp)
                        .width(369.dp),painter = painterResource(id = R.drawable.edt), contentDescription = "")

                    TextField(
                        modifier = Modifier/*.background()*/
                            /* .height(50.dp)
                             .width(269.dp)*/
                            .alpha(0.001f),
                        value = text3,

                        onValueChange = { text3 = it },
                        label = { Text(modifier = Modifier.alpha(1f),text="Label") }
                    )

                    Text(text = "$text3", color = Color.White, fontSize = 15.sp)
                }
                Text(modifier =Modifier.padding(top=30.dp),text = " Задачи воплащения проекта", color = Color.White, fontSize = 15.sp)
                Box(modifier  =Modifier.padding(top=15.dp)/*.offset(y=100.dp)*/,contentAlignment = Alignment.Center){

                    Image( modifier = Modifier/*.background()*/
                        .height(50.dp)
                        .width(369.dp),painter = painterResource(id = R.drawable.edt), contentDescription = "")

                    TextField(
                        modifier = Modifier/*.background()*/
                            /* .height(50.dp)
                             .width(269.dp)*/
                            .alpha(0.001f),
                        value = text4,

                        onValueChange = { text4 = it },
                        label = { Text(modifier = Modifier.alpha(1f),text="Label") }
                    )

                    Text(text = "$text4", color = Color.White, fontSize = 15.sp)


                }
                Image(modifier =Modifier.padding(top=50.dp).clickable {startActivity(toRas)  },painter = painterResource(id = R.drawable.btn_next), contentDescription =" btnnext" )





                //BottomBar
                Row(modifier = Modifier
                    /*.offset(y = -21.dp)*/
                    // .background(Color(red = 27, green = 45, blue = 59))
                    /*.fillMaxWidth(0.9f)*/
                    /*.fillMaxHeight(0.1f)*/
                   // .fillMaxSize(0.1f),

                    .offset(y=50.dp)
                   , horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.Bottom)

                {

                    Image(painter = painterResource(id = R.drawable.mainicon) , contentDescription = "Button home")
                    Spacer(modifier = Modifier.width(85.dp))
                    Image(painter = painterResource(id = R.drawable.profilemain) , contentDescription = "Button home",Modifier.clickable {
                        startActivity(toProfile)
                        finish()
                    }


                    )
                    Spacer(modifier = Modifier.width(85.dp))
                    Image(painter = painterResource(id = R.drawable.exitmenu) , contentDescription = "Button home",Modifier.clickable {
                        startActivity(toAuth)
                        finish()
                    })
//            Spacer(modifier = Modifier.width(25.dp))
//            Image(painter = painterResource(id = R.drawable.api) , contentDescription = "Button home")

                }

            }



        }




    }







