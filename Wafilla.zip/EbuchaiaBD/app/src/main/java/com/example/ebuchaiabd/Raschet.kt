package com.example.ebuchaiabd

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Color.Companion.Green
import androidx.compose.ui.graphics.Color.Companion.White
import androidx.compose.ui.graphics.Color.Companion.Yellow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ebuchaiabd.ui.theme.EbuchaiaBDTheme

class Raschet : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Rasschet()
            Shapka()


           // MyUI2()

        }

    }
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun MyUI2() {
        val moviesList = listOf(
            "Iron Man",
            "Thor: Ragnarok",
            "Captain America: Civil War",
            "Doctor Strange",
            "The Incredible Hulk",
            "Ant-Man and the Wasp"
        )
        var expanded by remember { mutableStateOf(false) }
        var textFieldValue by remember { mutableStateOf("") }

        // container for textfield and menu
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = {
                expanded = !expanded
            }
        ) {
            // textfield
            TextField(
                modifier = Modifier
                    .menuAnchor(), // menuAnchor modifier must be passed to the text field for correctness
                value = textFieldValue,
                onValueChange = { newValue ->
                    textFieldValue = newValue
                },
                label = { Text("Movies") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                colors = ExposedDropdownMenuDefaults.textFieldColors(),
            )

            // filter options based on text field value
            val filteringOptions = moviesList.filter { it.contains(textFieldValue, ignoreCase = true) }
            if (filteringOptions.isNotEmpty()) {
                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false },
                ) {
                    filteringOptions.forEach { selectedMovie_ ->
                        DropdownMenuItem(
                            text = { Text(selectedMovie_) },
                            onClick = {
                                textFieldValue = selectedMovie_
                                expanded = false
                            },
                            contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding,
                        )
                    }
                }
            }
        }
    }



    @Composable
    fun Shapka(){
        Row(Modifier/*.fillMaxWidth()*/) {
            Image(
                modifier = Modifier.fillMaxWidth(),
                painter = painterResource(id = R.drawable.group45), contentDescription = "topBAr", contentScale = ContentScale.FillWidth)
        }
    }


    @Composable
    fun MyUI() {
        var expanded by remember { mutableStateOf(false) }
        val contextForToast = LocalContext.current.applicationContext

        Box(
            modifier = Modifier
                .fillMaxSize()
                .wrapContentSize(align = Alignment.Center)
                /*.padding(top = 80.dp, end = 164.dp)*/
                .offset(x = -164.dp, y = 80.dp),
            contentAlignment = Alignment.Center
        ) {


            // vertical 3 dots icon
            Image(

                painterResource(id =R.drawable.plusicon ), contentDescription = null,modifier = Modifier.clickable {expanded = true  }
               /* onClick = {
                    expanded = true
                }*/
            )

            // menu
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                // menu items
                DropdownMenuItem(
                    text = {
                        Text("Edit")
                    },
                    onClick = {
                        Toast.makeText(contextForToast, "Edit", Toast.LENGTH_SHORT).show()
                        expanded = false
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Outlined.Edit,
                            contentDescription = null
                        )
                    }
                )

                DropdownMenuItem(
                    text = {
                        Text("Settings")
                    },
                    onClick = {
                        Toast.makeText(contextForToast, "Settings", Toast.LENGTH_SHORT).show()
                        expanded = false
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Outlined.Settings,
                            contentDescription = null
                        )
                    }
                )

                DropdownMenuItem(
                    text = {
                        Text("Send Feedback")
                    },
                    onClick = {
                        Toast.makeText(contextForToast, "Send Feedback", Toast.LENGTH_SHORT).show()
                        expanded = false
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Outlined.Email,
                            contentDescription = null
                        )
                    }
                )
            }




        }

    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    @Preview(showBackground = true)
    fun Rasschet(){
        val moviesList = listOf(
            "Iron Man",
            "Thor: Ragnarok",
            "Captain America: Civil War",
            "Doctor Strange",
            "The Incredible Hulk",
            "Ant-Man and the Wasp"
        )
        var expanded by remember { mutableStateOf(false) }
        var textFieldValue by remember { mutableStateOf("") }


            val contextForToast = LocalContext.current.applicationContext
            var dobav  by remember{mutableStateOf(false)}

        var speci= arrayOf("UX Дизайнер","Kotlin Разработчик","Проектный мэнэджер")
        var specCost = arrayOf("90000","120000","70000")
        var toMain= Intent(this, Main::class.java)
        Card(
            modifier = Modifier
                .padding(top = 60.dp)
                .background(Color(red = 27, green = 45, blue = 59))

        ){

            Column(
                modifier = Modifier
                    .background(Color(red = 27, green = 45, blue = 59))
                    .fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally
                , /*verticalArrangement = Arrangement.Center*/
            ) {

                var text by remember { mutableStateOf("") }
                // var EdtText:String=""
                OutlinedTextField(modifier = Modifier
                    .background(Color(red = 27, green = 45, blue = 59))
                    .padding(top = 26.dp),
                    textStyle = TextStyle(color = Color.White, fontWeight = FontWeight.Bold),
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(red = 141, green = 229, blue = 165),
                        unfocusedBorderColor = Color(red = 95, green = 210, blue = 159)
                    ),
                    // color: TextFieldColors = TextFieldDefaults.textFieldColors(),
                    value = text,
                    onValueChange = { text = it },
                    label = {
                        Text(
                            text = "Название проекта",
                            color = Color(red = 141, green = 229, blue = 165)
                        )
                    }
                )

                Row(
                    modifier = Modifier.padding(top = 23.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        modifier = Modifier.fillMaxWidth(0.45f),
                        text = "Команда", color = Color.White
                    )
                    Text(
                        modifier = Modifier
                            .fillMaxWidth(0.5f)
                            .padding(top = 20.dp),
                        text = "Средняя ЗП Спициалиста", color = Color.White
                    )
                }
                LazyColumn(
                    modifier = Modifier
                        .background(Color(red = 27, green = 45, blue = 59))
                        .fillMaxHeight(0.35f)
                        .fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally

                ) {
                    itemsIndexed(speci) { index, spec ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(start = 55.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                Modifier
                                    .fillMaxWidth(0.5f)
                                    .padding(top = 24.dp)
                            ) {
                                Text(text = speci[index], color = Color.White)
                            }
                            Column(Modifier.padding(start = 20.dp, top = 24.dp)) {
                                Text(
                                    text = specCost[index], color = Color.White
                                )

                            }
                        }
                    }


                }

                if (dobav == false) {

                //После спецов
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(
                        horizontalAlignment = Alignment.End
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.plusicon),
                            contentDescription = "plus",
                            modifier = Modifier.clickable {
                            dobav=true

                            }
                        )
                    }


                    Text(
                        modifier = Modifier
                            .fillMaxWidth(0.4f)
                            .offset(x = 15.dp),
                        text = "Добавить специалиста", color = Color.White
                    )
                }
                Text(
                    modifier = Modifier
                        .padding(top = 35.dp)
                        .fillMaxWidth(0.4f),
                    textAlign = TextAlign.Center,
                    text = "Примерное время разработки", color = White
                )

                var prjlong: String = "3 месяца"
                Text(
                    modifier = Modifier
                        .padding(top = 8.dp)
                        .fillMaxWidth(0.4f),
                    textAlign = TextAlign.Center, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                    text = prjlong, color = White
                )
                var totalCost = 0
                for (i in specCost) {
                    totalCost = totalCost + i.toInt()
                }


                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        modifier = Modifier
                            .fillMaxWidth(0.6f)
                            .padding(start = 58.dp, top = 35.dp),
                        textAlign = TextAlign.Center,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        text = "Итоговая стоимость",
                        color = White
                    )

                    Text(
                        modifier = Modifier
                            .padding(top = 8.dp)
                            .fillMaxWidth()
                            .padding(end = 58.dp),
                        textAlign = TextAlign.Center,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        text = totalCost.toString(),
                        color = White
                    )

                }
            }else if (dobav==true){
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(
                            horizontalAlignment = Alignment.End
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.minus),
                                contentDescription = "minus",
                                modifier = Modifier.clickable {
                                    dobav=false

                                }
                            )
                        }


                        Text(
                            modifier = Modifier
                                .fillMaxWidth(0.4f)
                                .offset(x = 15.dp),
                            text = "Добавить специалиста", color = Color.White
                        )


                    }

                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = {
                            expanded = !expanded
                        }
                    ) {
                        // textfield
                        TextField(
                            modifier = Modifier
                                .menuAnchor(), // menuAnchor modifier must be passed to the text field for correctness
                            value = textFieldValue,
                            onValueChange = { newValue ->
                                textFieldValue = newValue
                            },
                            label = { Text(text="Movies", color=Color(red = 141, green = 229, blue = 165) ) },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                           textStyle = TextStyle(color = Color.White, fontWeight = FontWeight.Bold),
                            colors = TextFieldDefaults.outlinedTextFieldColors(
                                focusedBorderColor = Color(red = 141, green = 229, blue = 165),
                                unfocusedBorderColor = Color(red = 95, green = 210, blue = 159)
                            ),
                        )

                        // filter options based on text field value
                        val filteringOptions = moviesList.filter { it.contains(textFieldValue, ignoreCase = true) }
                        if (filteringOptions.isNotEmpty()) {
                            ExposedDropdownMenu(
                                expanded = expanded,
                                onDismissRequest = { expanded = false },
                            ) {
                                filteringOptions.forEach { selectedMovie_ ->
                                    DropdownMenuItem(
                                        text = { Text(selectedMovie_) },
                                        onClick = {
                                            textFieldValue = selectedMovie_
                                            expanded = false
                                        },
                                        contentPadding = ExposedDropdownMenuDefaults.ItemContentPadding,
                                    )
                                }
                            }
                        }
                    }

                    Text(
                        modifier = Modifier
                            .padding(top = 35.dp)
                            .fillMaxWidth(0.4f),
                        textAlign = TextAlign.Center,
                        text = "Примерное время разработки", color = White
                    )

                    var prjlong: String = "3 месяца"
                    Text(
                        modifier = Modifier
                            .padding(top = 8.dp)
                            .fillMaxWidth(0.4f),
                        textAlign = TextAlign.Center, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                        text = prjlong, color = White
                    )
                    var totalCost = 0
                    for (i in specCost) {
                        totalCost = totalCost + i.toInt()
                    }


                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            modifier = Modifier
                                .fillMaxWidth(0.6f)
                                .padding(start = 58.dp, top = 35.dp),
                            textAlign = TextAlign.Center,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            text = "Итоговая стоимость",
                            color = White
                        )

                        Text(
                            modifier = Modifier
                                .padding(top = 8.dp)
                                .fillMaxWidth()
                                .padding(end = 58.dp),
                            textAlign = TextAlign.Center,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            text = totalCost.toString(),
                            color = White
                        )

                    }

            }




              Image(modifier = Modifier.offset(y=20.dp),painter = painterResource( id = R.drawable.fromzapoln), contentDescription ="" )
        }
    }



}
}

