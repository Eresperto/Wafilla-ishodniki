package com.example.ebuchaiabd

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Card
import androidx.compose.material3.CardElevation
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ebuchaiabd.ui.theme.EbuchaiaBDTheme

class NewReg : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            //Regs()
        page()
            Shapka()
        }



    }

    @Composable
    fun Shapka(){
        Row(Modifier/*.fillMaxWidth()*/) {
            Image(
                modifier = Modifier.fillMaxWidth(),
                painter = painterResource(id = R.drawable.group45), contentDescription = "topBAr", contentScale = ContentScale.FillWidth)
        }
    }


@Composable
//@Preview(showBackground = true)
fun page(){

    var toAuth= Intent(this,Main::class.java )

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(top = 50.dp)
        .background(Color(red = 27, green = 45, blue = 59)), horizontalAlignment = Alignment.CenterHorizontally) {

        Image(modifier = Modifier.padding(end=300.dp,top=30.dp),painter = painterResource(id = R.drawable.icon_profile), contentDescription = "icon")
        Spacer(modifier = Modifier.height(21.dp))
        Image(modifier = Modifier.padding(end=200.dp),painter = painterResource(id = R.drawable.txtreg), contentDescription = "txtreg")
        Spacer(modifier = Modifier.height(21.dp))
        Image(painter = painterResource(id = R.drawable.line), contentDescription = "line")

        var text by remember { mutableStateOf("") }
        var text1 by remember { mutableStateOf("") }
        var text2 by remember { mutableStateOf("") }
        var text3 by remember { mutableStateOf("") }

        Text(modifier  =Modifier.padding(top=35.dp,end=270.dp),text = "Имя",color=Color.White)
        Box(modifier  =Modifier.padding(end=34.dp,start=34.dp)/*.offset(y=100.dp)*/,contentAlignment = Alignment.Center){
            Image( modifier = Modifier/*.background()*/
                .height(50.dp)
                .width(407.dp),painter = painterResource(id = R.drawable.edt), contentDescription = "")

            TextField(
                modifier = Modifier/*.background()*/
                    /* .height(50.dp)
                     .width(269.dp)*/
                    .alpha(0.001f),
                value = text,

                onValueChange = { text = it },
                label = { Text(modifier = Modifier.alpha(1f),text="Label") }
            )
            Text(text = "$text", color = Color.White, fontSize = 15.sp)
        }

        Text(modifier = Modifier.padding(top=35.dp,end=260.dp),text = "Логин",color=Color.White)
        Box(modifier  =Modifier.padding(end=34.dp,start=34.dp)/*.offset(y=100.dp)*/,contentAlignment = Alignment.Center){
            Image( modifier = Modifier/*.background()*/
                .height(50.dp)
                .width(407.dp),painter = painterResource(id = R.drawable.edt), contentDescription = "")

            TextField(
                modifier = Modifier/*.background()*/
                    /* .height(50.dp)
                     .width(269.dp)*/
                    .alpha(0.001f),
                value = text1,

                onValueChange = { text1 = it },
                label = { Text(modifier = Modifier.alpha(1f),text="Label") }
            )

            Text(text = "$text1", color = Color.White, fontSize = 15.sp)

        }


        Text(modifier  =Modifier.padding(top=35.dp,end=260.dp),text = "Пароль", color= Color.White)
        Box(modifier  =Modifier.padding(start=34.dp,end=34.dp)/*.offset(y=100.dp)*/,contentAlignment = Alignment.Center){

            Image( modifier = Modifier/*.background()*/
                .height(50.dp)
                .width(407.dp),painter = painterResource(id = R.drawable.edt), contentDescription = "")

            TextField(
                modifier = Modifier/*.background()*/
                    /* .height(50.dp)
                     .width(269.dp)*/
                    .alpha(0.001f),
                value = text2,

                onValueChange = { text2 = it },
                label = { Text(modifier = Modifier.alpha(1f),text="Label") }
            )

            Text(text = "$text2", color = Color.White, fontSize = 15.sp)

        }

            Text(modifier  =Modifier.padding(top=35.dp,end=210.dp),text = " Номер телефона", color = Color.White)


        Box(modifier  =Modifier.padding(top=10.dp,start=34.dp,end=34.dp)/*.offset(y=100.dp)*/,contentAlignment = Alignment.Center){

            Image( modifier = Modifier/*.background()*/
                .height(50.dp)
                .width(407.dp),painter = painterResource(id = R.drawable.edt), contentDescription = "")

            TextField(
                modifier = Modifier/*.background()*/
                    /* .height(50.dp)
                     .width(269.dp)*/
                    .alpha(0.001f),
                value = text3,

                onValueChange = { text3 = it },
                label = { Text(modifier = Modifier.alpha(1f),text="Label") }
            )

            Text(text = "$text3", color = Color.White, fontSize = 15.sp)

        }


        Image(modifier  =Modifier.padding(40.dp)
            .clickable { startActivity(toAuth) },
            painter = painterResource(id = R.drawable.btn_reg), contentDescription = "btn_reg")
    }




}


    @Composable
   // @Preview(showBackground = true)
    fun pole(){
        var text by remember { mutableStateOf("") }
    Box(modifier  =Modifier.padding(top=100.dp)/*.offset(y=100.dp)*/,contentAlignment = Alignment.Center){

        Image( modifier = Modifier/*.background()*/
            .height(50.dp)
            .width(269.dp),painter = painterResource(id = R.drawable.edt), contentDescription = "")

        TextField(
                        modifier = Modifier/*.background()*/
                           /* .height(50.dp)
                            .width(269.dp)*/
                            .alpha(0.001f),
                        value = text,

                        onValueChange = { text = it },
                        label = { Text(modifier = Modifier.alpha(1f),text="Label") }
                    )

            Text(text = "$text", color = Color.White, fontSize = 15.sp)


    }




    }



    @Composable
    fun pole2(){




        
    }

    @Composable
   // @Preview(showBackground = true)
    fun Regs(){

        var text by remember { mutableStateOf("") }
        Column(modifier = Modifier
            .fillMaxSize()
            .background(Color(red = 27, green = 45, blue = 59))
            ) {

            Image(painter = painterResource(id = R.drawable.regshapka), contentDescription = "icon",Modifier.offset(x = 39.dp, y = 88.dp))

            Image(modifier =Modifier.offset(/*x = 39.dp*//*,*/ y = 118.dp),painter = painterResource(id = R.drawable.line), contentDescription ="line" )


            Column (Modifier.offset(x=33.dp , y=235.dp)){


//                Column(
//                    horizontalAlignment = Alignment.CenterHorizontally,
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .fillMaxHeight()
//                        .padding(20.dp)) {
//                    Card(
//                       modifier =  Modifier.height(100.dp).weight(0.7f)
//                    ) {
//                        Image(painter = painterResource(id = R.drawable.edt), contentDescription = null)
//                        Column(modifier = Modifier.padding(10.dp)) {
//
//                        }
//                    }
//                }


//                Card (){
//                    TextField(
//                        modifier = Modifier/*.background()*/,
//                        value = text,
//                        onValueChange = { text = it },
//                        label = { Text("Label") }
//                    )
//                }

            }

            }


            }



        }








